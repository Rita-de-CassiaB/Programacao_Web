package school.sptech.projetoestoque.service

import org.springframework.stereotype.Service

@Service
class CalculadoraService {

    fun calcularPrecoVenda(precoCompra:Double): Double {
        val precoVenda = precoCompra * 1.15

        return precoVenda
    }
}