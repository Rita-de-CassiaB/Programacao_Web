package Schoo.sptech.projetoestoque

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ProjetoEstoqueApplication

fun main(args: Array<String>) {
	runApplication<ProjetoEstoqueApplication>(*args)
}
