insert into sabores (nome, preco_base) values
('marguerita', 25.75),
('carne seca com catupiry', 29.50),
('portuguesa', 32.95);

insert into pizza (sabores_codigo, tamanho) values
(1,0),
(1,1),
(3,0),
(3,2),
(2,0),
(2,1);
