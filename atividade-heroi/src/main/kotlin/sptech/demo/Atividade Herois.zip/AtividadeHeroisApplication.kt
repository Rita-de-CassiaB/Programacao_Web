package sptech.demo

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class AtividadeHeroisApplication

fun main(args: Array<String>) {
	runApplication<AtividadeHeroisApplication>(*args)
}
