package sptech.demo

class Heroi (
    var nome:String,
    var habilidade:String,
    var idade:Int,
    var forca:Int,
    var vivo:Boolean,
){
}