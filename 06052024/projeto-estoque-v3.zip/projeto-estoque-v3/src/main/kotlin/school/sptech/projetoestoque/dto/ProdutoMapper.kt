package school.sptech.projetoestoque.dto

import school.sptech.projetoestoque.dominio.Produto

/*
Aqui nós implementamos um padrão de projeto chamado Adapter
Ou seja, nós ADAPTAMOS um tipo de classe para outro
 */
class ProdutoMapper {

    /*
    Aqui nós ADAPTAMOS (transformamos) um Produto em um ProdutoSimplesResponse
     */
    fun toProdutoSimples(produto: Produto): ProdutoSimplesResponse {
        val dto = ProdutoSimplesResponse(
            id = produto.id,
            nome = produto.nome,
            fabricante = produto.fabricante!!.nome
        )
        return dto
    }

/*
Aqui nós ADAPTAMOS (transformamos) uma lista de Produto em uma lista de ProdutoSimplesResponse
 */
    fun toProdutoSimplesList(produtos: List<Produto>):
            List<ProdutoSimplesResponse> {

//        return produtos.map(::toProdutoSimples)
        return produtos.map { produto -> toProdutoSimples(produto) }
    }
}