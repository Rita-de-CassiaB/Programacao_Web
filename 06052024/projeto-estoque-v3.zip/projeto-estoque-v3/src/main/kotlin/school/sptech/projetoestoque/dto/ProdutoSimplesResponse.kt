package school.sptech.projetoestoque.dto

data class ProdutoSimplesResponse(
    val id: Int?,
    val nome: String?,
    val fabricante: String?
)